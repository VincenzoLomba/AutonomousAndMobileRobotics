/*********************************************************************
 *
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2008, Robert Bosch LLC.
 *  Copyright (c) 2015-2016, Jiri Horner.
 *  Copyright (c) 2021, Carlos Alvarez, Juan Galvis.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of the Jiri Horner nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 *********************************************************************/

#include <explore/explore.h>

#include <thread>

#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>
#include <tf2/utils.h>
#include <angles/angles.h>

inline static bool same_point(const geometry_msgs::msg::Point& one,
                              const geometry_msgs::msg::Point& two)
{
  double dx = one.x - two.x;
  double dy = one.y - two.y;
  double dist = sqrt(dx * dx + dy * dy);
  return dist < 0.01;
}

namespace explore
{
Explore::Explore()
  : Node("explore_node")
  , logger_(this->get_logger())
  , tf_buffer_(this->get_clock())
  , tf_listener_(tf_buffer_)
  , costmap_client_(*this, &tf_buffer_)
  , prev_distance_(0)
  , last_markers_count_(0)
{
  double timeout;
  double min_frontier_size;
  this->declare_parameter<float>("planner_frequency", 1.0);
  this->declare_parameter<float>("progress_timeout", 30.0);
  this->declare_parameter<bool>("visualize", false);
  this->declare_parameter<float>("potential_scale", 1e-3);
  this->declare_parameter<float>("orientation_scale", 0.0);
  this->declare_parameter<float>("gain_scale", 1.0);
  this->declare_parameter<float>("min_frontier_size", 0.5);
  this->declare_parameter<bool>("return_to_init", false);

  this->get_parameter("planner_frequency", planner_frequency_);
  this->get_parameter("progress_timeout", timeout);
  this->get_parameter("visualize", visualize_);
  this->get_parameter("potential_scale", potential_scale_);
  this->get_parameter("orientation_scale", orientation_scale_);
  this->get_parameter("gain_scale", gain_scale_);
  this->get_parameter("min_frontier_size", min_frontier_size);
  this->get_parameter("return_to_init", return_to_init_);
  this->get_parameter("robot_base_frame", robot_base_frame_);

  progress_timeout_ = timeout;
  move_base_client_ =
      rclcpp_action::create_client<nav2_msgs::action::NavigateToPose>(
          this, ACTION_NAME);
  compute_path_client_ =
      rclcpp_action::create_client<nav2_msgs::action::ComputePathToPose>(
          this, "compute_path_to_pose");
  spin_client_ =
      rclcpp_action::create_client<nav2_msgs::action::Spin>(
          this, "spin");

  search_ = frontier_exploration::FrontierSearch(costmap_client_.getCostmap(),
                                                 potential_scale_, gain_scale_,
                                                 min_frontier_size, logger_);

  if (visualize_) {
    marker_array_publisher_ =
        this->create_publisher<visualization_msgs::msg::MarkerArray>("explore/"
                                                                     "frontier"
                                                                     "s",
                                                                     10);
  }

  // Publisher for exploration status
  rclcpp::QoS status_qos(10);
  status_qos.transient_local();
  status_pub_ = this->create_publisher<explore_lite_msgs::msg::ExploreStatus>("explore/status", status_qos);

  // Subscription to resume or stop exploration
  resume_subscription_ = this->create_subscription<std_msgs::msg::Bool>(
      "explore/resume", 10,
      std::bind(&Explore::resumeCallback, this, std::placeholders::_1));

  RCLCPP_INFO(logger_, "Waiting to connect to move_base nav2 server");
  move_base_client_->wait_for_action_server();
  RCLCPP_INFO(logger_, "Connected to move_base nav2 server");

  RCLCPP_INFO(logger_, "Waiting to connect to Nav2 compute_path_to_pose server");
  compute_path_client_->wait_for_action_server();
  RCLCPP_INFO(logger_, "Connected to Nav2 compute_path_to_pose server");

  RCLCPP_INFO(logger_, "Waiting to connect to Nav2 spin server");
  spin_client_->wait_for_action_server();
  RCLCPP_INFO(logger_, "Connected to Nav2 spin server");

  if (return_to_init_) {
    RCLCPP_INFO(logger_, "Getting initial pose of the robot");
    geometry_msgs::msg::TransformStamped transformStamped;
    std::string map_frame = costmap_client_.getGlobalFrameID();
    try {
      transformStamped = tf_buffer_.lookupTransform(
          map_frame, robot_base_frame_, tf2::TimePointZero);
      initial_pose_.position.x = transformStamped.transform.translation.x;
      initial_pose_.position.y = transformStamped.transform.translation.y;
      initial_pose_.orientation = transformStamped.transform.rotation;
    } catch (tf2::TransformException& ex) {
      RCLCPP_ERROR(logger_, "Couldn't find transform from %s to %s: %s",
                   map_frame.c_str(), robot_base_frame_.c_str(), ex.what());
      return_to_init_ = false;
    }
  }

  exploring_timer_ = this->create_wall_timer(
      std::chrono::milliseconds((uint16_t)(1000.0 / planner_frequency_)),
      [this]() { makePlan(); });
  // Start exploration right away
  auto status_msg = explore_lite_msgs::msg::ExploreStatus();
  status_msg.status = explore_lite_msgs::msg::ExploreStatus::EXPLORATION_STARTED;
  status_pub_->publish(status_msg);
  makePlan();
}

Explore::~Explore()
{
  stop();
}

void Explore::resumeCallback(const std_msgs::msg::Bool::SharedPtr msg)
{
  if (msg->data) {
    resume();
  } else {
    stop();
  }
}

void Explore::visualizeFrontiers(
    const std::vector<frontier_exploration::Frontier>& frontiers)
{
  const auto blue = std_msgs::msg::ColorRGBA().set__b(1.0).set__a(0.5);
  const auto red = std_msgs::msg::ColorRGBA().set__r(1.0).set__a(0.5);
  const auto green = std_msgs::msg::ColorRGBA().set__g(1.0).set__a(0.5);

  RCLCPP_DEBUG(logger_, "visualising %lu frontiers", frontiers.size());
  visualization_msgs::msg::MarkerArray markers_msg;
  std::vector<visualization_msgs::msg::Marker>& markers = markers_msg.markers;
  visualization_msgs::msg::Marker m;

  m.header.frame_id = costmap_client_.getGlobalFrameID();
  m.header.stamp = this->now();
  m.ns = "frontiers";
  m.scale.x = 1.0;
  m.scale.y = 1.0;
  m.scale.z = 1.0;
  m.color.r = 0;
  m.color.g = 0;
  m.color.b = 255;
  m.color.a = 255;
  // m.lifetime defaults to 0, means lives forever
  m.frame_locked = true;

  // weighted frontiers are always sorted
  double min_cost = frontiers.empty() ? 0. : frontiers.front().cost;

  m.action = visualization_msgs::msg::Marker::ADD;
  size_t id = 0;
  for (auto& frontier : frontiers) {
    m.type = visualization_msgs::msg::Marker::POINTS;
    m.id = int(id);
    m.pose.position.x = 0.0;
    m.pose.position.y = 0.0;
    m.pose.position.z = 0.0;
    m.scale.x = 0.1;
    m.scale.y = 0.1;
    m.scale.z = 0.1;
    m.points = frontier.points;
    if (goalOnBlacklist(frontier.centroid)) {
      m.color = red;
    } else {
      m.color = blue;
    }
    markers.push_back(m);
    ++id;
    m.type = visualization_msgs::msg::Marker::SPHERE;
    m.id = int(id);
    m.pose.position = frontier.centroid;
    // scale frontier according to its cost (costier frontiers will be smaller)
    double scale = std::min(std::abs(min_cost * 0.4 / frontier.cost), 0.5);
    m.scale.x = scale;
    m.scale.y = scale;
    m.scale.z = scale;
    m.points = {};
    m.color = green;
    markers.push_back(m);
    ++id;
  }
  size_t current_markers_count = markers.size();

  // delete previous markers, which are now unused
  m.action = visualization_msgs::msg::Marker::DELETE;
  for (; id < last_markers_count_; ++id) {
    m.id = int(id);
    markers.push_back(m);
  }

  last_markers_count_ = current_markers_count;
  marker_array_publisher_->publish(markers_msg);
}

void Explore::makePlan()
{
  checkCustomSequenceWatchdogs();

  // find frontiers
  auto pose = costmap_client_.getRobotPose();
  // get frontiers sorted according to cost
  auto frontiers = search_.searchFrom(pose.position);
  RCLCPP_DEBUG(logger_, "found %lu frontiers", frontiers.size());
  for (size_t i = 0; i < frontiers.size(); ++i) {
    RCLCPP_DEBUG(logger_, "frontier %zd cost: %f", i, frontiers[i].cost);
  }

  if (frontiers.empty()) {
    RCLCPP_WARN(logger_, "No frontiers found, stopping.");
    auto status_msg = explore_lite_msgs::msg::ExploreStatus();
    status_msg.status = explore_lite_msgs::msg::ExploreStatus::EXPLORATION_COMPLETE;
    status_pub_->publish(status_msg);
    stop(true);
    return;
  }

  // publish frontiers as visualization markers
  if (visualize_) {
    visualizeFrontiers(frontiers);
  }

  // find non blacklisted frontier
  auto frontier =
      std::find_if_not(frontiers.begin(), frontiers.end(),
                       [this](const frontier_exploration::Frontier& f) {
                         return goalOnBlacklist(f.centroid);
                       });
  if (frontier == frontiers.end()) {
    RCLCPP_WARN(logger_, "All frontiers traversed/tried out, stopping.");
    auto status_msg = explore_lite_msgs::msg::ExploreStatus();
    status_msg.status = explore_lite_msgs::msg::ExploreStatus::EXPLORATION_COMPLETE;
    status_pub_->publish(status_msg);
    stop(true);
    return;
  }
  geometry_msgs::msg::Point target_position = frontier->centroid;

  // time out if we are not making any progress
  bool same_goal = same_point(prev_goal_, target_position);

  prev_goal_ = target_position;
  if (!same_goal || prev_distance_ > frontier->min_distance) {
    // we have different goal or we made some progress
    last_progress_ = this->now();
    prev_distance_ = frontier->min_distance;
  }
  // black list if we've made no progress for a long time
  if ((this->now() - last_progress_ >
      tf2::durationFromSec(progress_timeout_)) && !resuming_) {
    frontier_blacklist_.push_back(target_position);
    RCLCPP_DEBUG(logger_, "Adding current goal to black list");
    makePlan();
    return;
  }

  // ensure only first call of makePlan was set resuming to true
  if (resuming_) {
    resuming_ = false;
  }

  // we don't need to do anything if we still pursuing the same goal
  if (same_goal) {
    return;
  }

  if (custom_sequence_state_ == CustomSequenceState::CANCEL_REQUESTED ||
      custom_sequence_state_ == CustomSequenceState::WAITING_NAV_TERMINATION) {
    pending_target_position_ = target_position;
    pending_target_valid_ = true;
    RCLCPP_DEBUG(logger_,
                 "A custom pre-rotation sequence is already canceling or waiting for the previous navigation to terminate. The latest target has been recorded and will be used when the sequence becomes dispatchable.");
    return;
  }

  if (custom_sequence_state_ == CustomSequenceState::PRE_ROTATION_PATH_REQUESTED ||
      custom_sequence_state_ == CustomSequenceState::SPIN_ACTIVE) {
    RCLCPP_DEBUG(logger_,
                 "A custom pre-rotation sequence is already computing a helper path or executing a spin. This makePlan() cycle will preserve normal frontier/progress/blacklist updates but will not dispatch any new custom sequence yet.");
    return;
  }

  beginCustomPreRotationSequence(target_position);
}

void Explore::sendNavigateToPoseGoal(
    const geometry_msgs::msg::Point& target_position)
{
  RCLCPP_DEBUG(logger_, "Sending canonical NavigateToPose goal to Nav2");

  custom_sequence_state_ = CustomSequenceState::NAV_ACTIVE;
  pending_target_valid_ = false;
  spin_in_progress_ = false;
  ++current_spin_generation_;
  nav_active_ = true;
  navigation_goal_handle_.reset();

  auto goal = nav2_msgs::action::NavigateToPose::Goal();
  goal.pose.pose.position = target_position;
  goal.pose.pose.orientation.w = 1.;
  goal.pose.header.frame_id = costmap_client_.getGlobalFrameID();
  goal.pose.header.stamp = this->now();

  const uint64_t goal_generation = ++current_nav_generation_;

  auto send_goal_options =
      rclcpp_action::Client<nav2_msgs::action::NavigateToPose>::SendGoalOptions();
  send_goal_options.goal_response_callback =
      [this, goal_generation](NavigationGoalHandle::SharedPtr goal_handle) {
        if (!goal_handle) {
          RCLCPP_ERROR(logger_,
                       "Canonical NavigateToPose goal was rejected by Nav2. ExploreLite will keep its internal logic alive and wait for the next makePlan() opportunity.");
          if (goal_generation == current_nav_generation_) {
            nav_active_ = false;
            navigation_goal_handle_.reset();
            custom_sequence_state_ = CustomSequenceState::IDLE;
          }
          return;
        }

        if (goal_generation == current_nav_generation_) {
          navigation_goal_handle_ = goal_handle;
          nav_active_ = true;
          custom_sequence_state_ = CustomSequenceState::NAV_ACTIVE;
        }
      };
  send_goal_options.result_callback =
      [this,
       target_position,
       goal_generation](const NavigationGoalHandle::WrappedResult& result) {
        if (goal_generation == current_nav_generation_) {
          nav_active_ = false;
          navigation_goal_handle_.reset();
        }
        reachedGoal(result, target_position);
      };
  move_base_client_->async_send_goal(goal, send_goal_options);
}

void Explore::beginCustomPreRotationSequence(
    const geometry_msgs::msg::Point& target_position)
{
  pending_target_position_ = target_position;
  pending_target_valid_ = true;
  cancel_ack_received_ = false;
  cancel_request_start_time_ = this->now();
  const uint64_t sequence_id = ++active_custom_sequence_id_;
  custom_sequence_state_ = CustomSequenceState::CANCEL_REQUESTED;

  RCLCPP_DEBUG(logger_,
               "Starting a new custom pre-rotation sequence. All active ExploreLite NavigateToPose goals will be canceled before requesting a fresh helper path.");

  move_base_client_->async_cancel_all_goals(
      [this, sequence_id](rclcpp_action::Client<nav2_msgs::action::NavigateToPose>::CancelResponse::SharedPtr response) {
        handleCancelAllGoalsResponse(response, sequence_id);
      });
}

void Explore::requestPathAndMaybePreRotate(
    const geometry_msgs::msg::Point& target_position)
{
  custom_sequence_state_ = CustomSequenceState::PRE_ROTATION_PATH_REQUESTED;
  auto goal = nav2_msgs::action::ComputePathToPose::Goal();
  goal.goal.pose.position = target_position;
  goal.goal.pose.orientation.w = 1.;
  goal.goal.header.frame_id = costmap_client_.getGlobalFrameID();
  goal.goal.header.stamp = this->now();
  goal.planner_id = "";
  goal.use_start = false;

  auto send_goal_options =
      rclcpp_action::Client<nav2_msgs::action::ComputePathToPose>::SendGoalOptions();
  send_goal_options.result_callback =
      [this,
       target_position](const ComputePathGoalHandle::WrappedResult& result) {
        handleComputePathResult(result, target_position);
      };

  compute_path_client_->async_send_goal(goal, send_goal_options);
}

bool Explore::tryExtractInitialPathHeading(const nav_msgs::msg::Path& path,
                                           double& heading) const
{
  if (path.poses.size() < 2) {
    return false;
  }

  constexpr double min_segment_length = 0.05;
  const auto& first_pose = path.poses.front().pose.position;
  for (size_t i = 1; i < path.poses.size(); ++i) {
    const auto& next_pose = path.poses[i].pose.position;
    const double dx = next_pose.x - first_pose.x;
    const double dy = next_pose.y - first_pose.y;
    const double dist = std::hypot(dx, dy);
    if (dist > min_segment_length) {
      heading = std::atan2(dy, dx);
      return true;
    }
  }

  return false;
}

void Explore::handleComputePathResult(
    const ComputePathGoalHandle::WrappedResult& result,
    const geometry_msgs::msg::Point& target_position)
{
  if (result.code != rclcpp_action::ResultCode::SUCCEEDED) {
    RCLCPP_ERROR(
        logger_,
        "Pre-rotation helper path request failed before NavigateToPose dispatch. "
        "ExploreLite will now deliberately fall back to its original canonical behavior: "
        "it will send the normal NavigateToPose goal without any custom pre-rotation, and "
        "Nav2 plus the existing ExploreLite logic will handle planning, replanning, recovery, "
        "timeouts, and any eventual frontier blacklisting exactly as in the unmodified package.");
    custom_sequence_state_ = CustomSequenceState::IDLE;
    pending_target_valid_ = false;
    sendNavigateToPoseGoal(target_position);
    return;
  }

  double desired_heading = 0.0;
  if (result.result->path.poses.empty() ||
      !tryExtractInitialPathHeading(result.result->path, desired_heading)) {
    RCLCPP_ERROR(
        logger_,
        "Pre-rotation helper path request succeeded but did not provide a usable global path "
        "heading for the custom pre-rotation step. ExploreLite will now deliberately fall back "
        "to its original canonical behavior: it will send the normal NavigateToPose goal without "
        "any custom pre-rotation, and Nav2 plus the existing ExploreLite logic will handle "
        "planning, replanning, recovery, timeouts, and any eventual frontier blacklisting exactly "
        "as in the unmodified package.");
    custom_sequence_state_ = CustomSequenceState::IDLE;
    pending_target_valid_ = false;
    sendNavigateToPoseGoal(target_position);
    return;
  }

  const auto robot_pose = costmap_client_.getRobotPose();
  const double current_yaw = tf2::getYaw(robot_pose.orientation);
  const double relative_spin = angles::shortest_angular_distance(current_yaw, desired_heading);

  if (std::abs(relative_spin) < 1e-3) {
    RCLCPP_DEBUG(logger_,
                 "Custom pre-rotation skipped because the robot is already aligned with the initial global path heading");
    custom_sequence_state_ = CustomSequenceState::IDLE;
    pending_target_valid_ = false;
    sendNavigateToPoseGoal(target_position);
    return;
  }

  auto spin_goal = nav2_msgs::action::Spin::Goal();
  spin_goal.target_yaw = static_cast<float>(relative_spin);
  spin_goal.time_allowance.sec = 20;
  spin_goal.time_allowance.nanosec = 0;

  const uint64_t spin_generation = ++current_spin_generation_;
  auto send_goal_options =
      rclcpp_action::Client<nav2_msgs::action::Spin>::SendGoalOptions();
  send_goal_options.result_callback =
      [this,
       target_position,
       spin_generation](const SpinGoalHandle::WrappedResult& result) {
        if (spin_generation != current_spin_generation_) {
          RCLCPP_WARN(logger_,
                      "Ignoring a stale Nav2 Spin result callback belonging to an older custom pre-rotation sequence.");
          return;
        }
        handleSpinResult(result, target_position);
      };

  RCLCPP_WARN(logger_,
              "Launching Nav2 Spin behavior for custom pre-rotation before NavigateToPose. Requested relative spin: %.6f rad (%.2f deg)",
              relative_spin, relative_spin * 180.0 / M_PI);
  spin_in_progress_ = true;
  spin_start_time_ = this->now();
  custom_sequence_state_ = CustomSequenceState::SPIN_ACTIVE;
  spin_client_->async_send_goal(spin_goal, send_goal_options);
}

void Explore::handleSpinResult(const SpinGoalHandle::WrappedResult& result,
                               const geometry_msgs::msg::Point& target_position)
{
  spin_in_progress_ = false;
  custom_sequence_state_ = CustomSequenceState::IDLE;
  pending_target_valid_ = false;

  if (result.code != rclcpp_action::ResultCode::SUCCEEDED) {
    RCLCPP_ERROR(
        logger_,
        "Custom pre-rotation via Nav2 Spin did not complete successfully. ExploreLite will now "
        "deliberately fall back to its original canonical behavior: it will send the normal "
        "NavigateToPose goal without any further custom interception, and Nav2 plus the existing "
        "ExploreLite logic will handle planning, replanning, recovery, timeouts, and any eventual "
        "frontier blacklisting exactly as in the unmodified package.");
  } else {
    RCLCPP_INFO(
        logger_,
        "Custom pre-rotation via Nav2 Spin completed successfully. ExploreLite will now send the canonical NavigateToPose goal.");
  }

  sendNavigateToPoseGoal(target_position);
}

void Explore::returnToInitialPose()
{
  RCLCPP_INFO(logger_, "Returning to initial pose.");
  auto status_msg = explore_lite_msgs::msg::ExploreStatus();
  status_msg.status = explore_lite_msgs::msg::ExploreStatus::RETURNING_TO_ORIGIN;
  status_pub_->publish(status_msg);

  auto goal = nav2_msgs::action::NavigateToPose::Goal();
  goal.pose.pose.position = initial_pose_.position;
  goal.pose.pose.orientation = initial_pose_.orientation;
  goal.pose.header.frame_id = costmap_client_.getGlobalFrameID();
  goal.pose.header.stamp = this->now();

  auto send_goal_options =
      rclcpp_action::Client<nav2_msgs::action::NavigateToPose>::SendGoalOptions();
  send_goal_options.result_callback =
      [this](const NavigationGoalHandle::WrappedResult& result) {
        if (result.code == rclcpp_action::ResultCode::SUCCEEDED) {
          auto status_msg = explore_lite_msgs::msg::ExploreStatus();
          status_msg.status = explore_lite_msgs::msg::ExploreStatus::RETURNED_TO_ORIGIN;
          status_pub_->publish(status_msg);
          RCLCPP_INFO(logger_, "Successfully returned to initial pose.");
        }
      };
  move_base_client_->async_send_goal(goal, send_goal_options);
}
bool Explore::goalOnBlacklist(const geometry_msgs::msg::Point& goal)
{
  constexpr static size_t tolerace = 5;
  nav2_costmap_2d::Costmap2D* costmap2d = costmap_client_.getCostmap();

  // check if a goal is on the blacklist for goals that we're pursuing
  for (auto& frontier_goal : frontier_blacklist_) {
    double x_diff = fabs(goal.x - frontier_goal.x);
    double y_diff = fabs(goal.y - frontier_goal.y);

    if (x_diff < tolerace * costmap2d->getResolution() &&
        y_diff < tolerace * costmap2d->getResolution())
      return true;
  }
  return false;
}

void Explore::handleCancelAllGoalsResponse(
    rclcpp_action::Client<nav2_msgs::action::NavigateToPose>::CancelResponse::SharedPtr response,
    uint64_t sequence_id)
{
  if (sequence_id != active_custom_sequence_id_) {
    RCLCPP_WARN(logger_,
                "Ignoring a stale NavigateToPose cancel-all acknowledgement belonging to an older custom pre-rotation sequence.");
    return;
  }

  cancel_ack_received_ = true;

  if (!response) {
    fallbackToCanonicalNavigate(
        "The NavigateToPose cancel-all callback returned a null response pointer. ExploreLite will now deliberately fall back to its original canonical behavior by dispatching the pending NavigateToPose goal without any custom helper path or spin.");
    return;
  }

  if (response->return_code == action_msgs::srv::CancelGoal::Response::ERROR_NONE) {
    RCLCPP_DEBUG(logger_,
                 "NavigateToPose cancel-all request was acknowledged by Nav2 and at least one goal entered the CANCELING state.");
  } else {
    RCLCPP_WARN(logger_,
                "NavigateToPose cancel-all request was acknowledged by Nav2 but return_code=%d and goals_canceling.size()=%zu. ExploreLite will keep following its local state machine and decide whether it still needs to wait for the current navigation result before proceeding.",
                static_cast<int>(response->return_code),
                response->goals_canceling.size());
  }

  if (!pending_target_valid_) {
    custom_sequence_state_ = nav_active_ ? CustomSequenceState::NAV_ACTIVE : CustomSequenceState::IDLE;
    return;
  }

  if (!nav_active_) {
    RCLCPP_DEBUG(logger_,
                 "NavigateToPose cancel-all request acknowledged and no frontier navigation is currently active. Proceeding directly with the helper path request for the pending target.");
    requestPathAndMaybePreRotate(pending_target_position_);
    return;
  }

  nav_termination_wait_start_time_ = this->now();
  custom_sequence_state_ = CustomSequenceState::WAITING_NAV_TERMINATION;
  RCLCPP_DEBUG(logger_,
               "NavigateToPose cancel-all request acknowledged. Waiting for the currently active frontier navigation to reach a terminal result before running the custom helper path request and spin.");
}

void Explore::tryAdvancePendingSequenceAfterNavTermination()
{
  if (!pending_target_valid_ || !cancel_ack_received_ || nav_active_) {
    return;
  }

  RCLCPP_DEBUG(logger_,
               "The previously active frontier navigation has now terminated. Proceeding with the helper path request for the pending custom pre-rotation sequence.");
  requestPathAndMaybePreRotate(pending_target_position_);
}

void Explore::fallbackToCanonicalNavigate(const char* error_message)
{
  if (error_message != nullptr) {
    RCLCPP_ERROR(logger_, "%s", error_message);
  }

  spin_in_progress_ = false;
  ++current_spin_generation_;
  cancel_ack_received_ = false;
  custom_sequence_state_ = CustomSequenceState::IDLE;

  if (pending_target_valid_) {
    const auto target_position = pending_target_position_;
    pending_target_valid_ = false;
    sendNavigateToPoseGoal(target_position);
  }
}

void Explore::checkCustomSequenceWatchdogs()
{
  const auto now = this->now();

  if (custom_sequence_state_ == CustomSequenceState::CANCEL_REQUESTED &&
      (now - cancel_request_start_time_ > tf2::durationFromSec(cancel_request_timeout_sec_))) {
    fallbackToCanonicalNavigate(
        "The custom pre-rotation sequence has been waiting too long for the NavigateToPose cancel-all acknowledgement. ExploreLite will now deliberately fall back to its original canonical behavior by dispatching the pending NavigateToPose goal without any custom helper path or spin.");
    return;
  }

  if (custom_sequence_state_ == CustomSequenceState::WAITING_NAV_TERMINATION &&
      (now - nav_termination_wait_start_time_ > tf2::durationFromSec(nav_termination_timeout_sec_))) {
    fallbackToCanonicalNavigate(
        "The custom pre-rotation sequence has been waiting too long for the previously active NavigateToPose goal to reach a terminal result after cancel-all was acknowledged. ExploreLite will now deliberately fall back to its original canonical behavior by dispatching the pending NavigateToPose goal without any custom helper path or spin.");
    return;
  }

  if (custom_sequence_state_ == CustomSequenceState::SPIN_ACTIVE &&
      (now - spin_start_time_ > tf2::durationFromSec(spin_watchdog_timeout_sec_))) {
    fallbackToCanonicalNavigate(
        "The custom pre-rotation sequence watchdog detected that Nav2 Spin has exceeded the local waiting budget before its result callback returned. ExploreLite will now deliberately fall back to its original canonical behavior by dispatching the pending NavigateToPose goal without waiting any longer for the custom spin result.");
  }
}

void Explore::reachedGoal(const NavigationGoalHandle::WrappedResult& result,
                          const geometry_msgs::msg::Point& frontier_goal)
{
  if (custom_sequence_state_ == CustomSequenceState::WAITING_NAV_TERMINATION) {
    tryAdvancePendingSequenceAfterNavTermination();
    return;
  }

  switch (result.code) {
    case rclcpp_action::ResultCode::SUCCEEDED:
      RCLCPP_DEBUG(logger_, "Goal was successful");
      custom_sequence_state_ = CustomSequenceState::IDLE;
      break;
    case rclcpp_action::ResultCode::ABORTED:
      RCLCPP_DEBUG(logger_, "Goal was aborted");
      frontier_blacklist_.push_back(frontier_goal);
      RCLCPP_DEBUG(logger_, "Adding current goal to black list");
      custom_sequence_state_ = CustomSequenceState::IDLE;
      // If it was aborted probably because we've found another frontier goal,
      // so just return and don't make plan again
      return;
    case rclcpp_action::ResultCode::CANCELED:
      RCLCPP_DEBUG(logger_, "Goal was canceled");
      custom_sequence_state_ = CustomSequenceState::IDLE;
      // If goal canceled might be because exploration stopped from topic. Don't make new plan.
      return;
    default:
      RCLCPP_WARN(logger_, "Unknown result code from move base nav2");
      custom_sequence_state_ = CustomSequenceState::IDLE;
      break;
  }

  makePlan();
}

void Explore::start()
{
  RCLCPP_INFO(logger_, "Exploration started.");
  auto status_msg = explore_lite_msgs::msg::ExploreStatus();
  status_msg.status = explore_lite_msgs::msg::ExploreStatus::EXPLORATION_STARTED;
  status_pub_->publish(status_msg);
}

void Explore::stop(bool finished_exploring)
{
  RCLCPP_INFO(logger_, "Exploration stopped.");
  finished_exploring_ = finished_exploring;

  // Only publish paused status if manually stopped (not finished exploring)
  if (!finished_exploring) {
    auto status_msg = explore_lite_msgs::msg::ExploreStatus();
    status_msg.status = explore_lite_msgs::msg::ExploreStatus::EXPLORATION_PAUSED;
    status_pub_->publish(status_msg);
  }

  move_base_client_->async_cancel_all_goals();
  exploring_timer_->cancel();
  spin_in_progress_ = false;
  ++current_spin_generation_;
  cancel_ack_received_ = false;
  pending_target_valid_ = false;
  custom_sequence_state_ = CustomSequenceState::IDLE;
  nav_active_ = false;

  if (return_to_init_ && finished_exploring) {
    returnToInitialPose();
  }
}

void Explore::resume()
{
  if (finished_exploring_) {
    frontier_blacklist_.clear();
    prev_goal_ = geometry_msgs::msg::Point();
    prev_distance_ = 0.0;
    last_progress_ = this->now();
    finished_exploring_ = false;
    move_base_client_->async_cancel_all_goals();
  }

  resuming_ = true;

  // Force the first planning cycle after resume to be treated as fresh.
  // This avoids an immediate early-return when the selected frontier matches
  // the previous goal and makes resumption noticeably more responsive.
  prev_goal_.x = std::numeric_limits<double>::quiet_NaN();
  prev_goal_.y = std::numeric_limits<double>::quiet_NaN();
  prev_distance_ = std::numeric_limits<double>::infinity();
  last_progress_ = this->now();

  RCLCPP_INFO(logger_, "Exploration resuming.");
  auto status_msg = explore_lite_msgs::msg::ExploreStatus();
  status_msg.status = explore_lite_msgs::msg::ExploreStatus::EXPLORATION_IN_PROGRESS;
  status_pub_->publish(status_msg);
  // Reactivate the timer
  exploring_timer_->reset();
  // Resume immediately
  makePlan();
}

}  // namespace explore

int main(int argc, char** argv)
{
  rclcpp::init(argc, argv);
  // ROS1 code
  /*
  if (ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME,
                                     ros::console::levels::Debug)) {
    ros::console::notifyLoggerLevelsChanged();
  } */
  rclcpp::spin(
      std::make_shared<explore::Explore>());  // std::move(std::make_unique)?
  rclcpp::shutdown();
  return 0;
}
